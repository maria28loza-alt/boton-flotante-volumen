package com.example.volumefloat

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(36, 36, 36, 36)
        }
        val title = TextView(this).apply {
            text = "Volume Float"
            textSize = 26f
            gravity = Gravity.CENTER
        }
        val info = TextView(this).apply {
            text = "Control de volumen flotante para Android 11"
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, 20, 0, 28)
        }
        val start = Button(this).apply { text = "Activar control flotante" }
        val stop = Button(this).apply { text = "Desactivar control flotante" }

        start.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName"))
                startActivity(intent)
            } else {
                startService(Intent(this, VolumeOverlayService::class.java))
            }
        }
        stop.setOnClickListener {
            stopService(Intent(this, VolumeOverlayService::class.java))
        }

        layout.addView(title)
        layout.addView(info)
        layout.addView(start)
        layout.addView(stop)
        setContentView(layout)
    }

    override fun onResume() {
        super.onResume()
        if (Settings.canDrawOverlays(this)) {
            // User can return here after granting overlay permission.
        }
    }
}
