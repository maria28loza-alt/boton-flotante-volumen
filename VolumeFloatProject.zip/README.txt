Volume Float — proyecto Android

Características:
- Botones flotantes + y − para ajustar volumen multimedia.
- Ventana superpuesta de Android.
- Control movible por arrastre.
- Android 6+; pensado para Android 11 (API 30).

Para compilar:
1. Abrir la carpeta del proyecto en Android Studio (Open).
2. Esperar a que Gradle sincronice y descargue componentes.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Instalar el APK generado en el Redmi Note 8.
5. Abrir Volume Float, tocar Activar control flotante y conceder "Mostrar sobre otras aplicaciones".
6. Volver a la app y activar el control.

Nota: Este proyecto fuente no es un APK ya compilado. Debe compilarse en Android Studio.
